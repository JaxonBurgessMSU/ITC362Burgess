package com.bignerdranch.android.criminalintent

import androidx.fragment.app.testing.FragmentScenario
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.test.espresso.Espresso
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CrimeDetailFragmentTest {

    @Test
    fun testCrimeDetailFragmentUI() {

        val scenario: FragmentScenario<CrimeDetailFragment> = launchFragmentInContainer()

        Espresso.onView(ViewMatchers.withId(R.id.crime_title))
            .perform(ViewActions.typeText("Something Happened"))
            .check(ViewAssertions.matches(ViewMatchers.withText("Something Happened")))

        Espresso.onView(ViewMatchers.withId(R.id.crime_solved))
            .perform(ViewActions.click())
            .check(ViewAssertions.matches(ViewMatchers.isChecked()))

    }
    
}
