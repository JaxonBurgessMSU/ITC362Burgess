package com.bignerdranch.android.photogallery.api

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

private const val BASE_URL = "https://api.flickr.com/"
private const val API_KEY = "686229863904506ea3c453e34940f88d"

private val okHttpClient = OkHttpClient.Builder().build()

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

private val retrofit = Retrofit.Builder()
    .baseUrl(BASE_URL)
    .client(okHttpClient)
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .build()

interface FlickrApi {
    @GET("services/rest/?method=flickr.interestingness.getList")
    suspend fun fetchPhotos(
        @Query("api_key") apiKey: String,
        @Query("format") format: String = "json",
        @Query("nojsoncallback") noJsonCallback: Int = 1,
        @Query("extras") extras: String = "url_s",
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 20
    ): FlickrResponse

    companion object {
        fun create(apiKey: String = API_KEY): FlickrApi {
            return retrofit.newBuilder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(FlickrApi::class.java)
                .apply {
                    // Add the API key to every request
                    (this as? retrofit2.Retrofit)?.let { retrofit ->
                        retrofit.newBuilder()
                            .addConverterFactory(MoshiConverterFactory.create(moshi))
                            .build()
                    }
                }
        }
    }
}

class FlickrApiImpl(private val apiKey: String) : FlickrApi {
    override suspend fun fetchPhotos(
        apiKey: String,
        format: String,
        noJsonCallback: Int,
        extras: String,
        page: Int,
        perPage: Int
    ): FlickrResponse {
        return retrofit.create(FlickrApi::class.java).fetchPhotos(
            apiKey,
            format,
            noJsonCallback,
            extras,
            page,
            perPage
        )
    }
}
