package com.bignerdranch.android.photogallery

import PhotoPagingSource
import com.bignerdranch.android.photogallery.api.FlickrApiImpl
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.bignerdranch.android.photogallery.api.FlickrApi
import com.bignerdranch.android.photogallery.api.GalleryItem
import kotlinx.coroutines.flow.Flow

class PhotoRepository(private val flickrApi: FlickrApi) {

    fun getPhotoPagingData(): Flow<PagingData<GalleryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = PAGE_SIZE,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { PhotoPagingSource(flickrApi) }
        ).flow
    }

    companion object {
        private const val PAGE_SIZE= 50


        fun create(apiKey: String): PhotoRepository {
            val flickrApi = FlickrApi.create(apiKey)
            return PhotoRepository(flickrApi)
        }
    }
}
