import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.bignerdranch.android.photogallery.api.FlickrApi
import com.bignerdranch.android.photogallery.api.FlickrResponse
import com.bignerdranch.android.photogallery.api.GalleryItem

class PhotoPagingSource(
    private val flickrApi: FlickrApi
) : PagingSource<Int, GalleryItem>() {

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, GalleryItem> {
        val page = params.key ?: 1

        return try {
            val response: FlickrResponse = flickrApi.fetchPhotos(
                apiKey = "686229863904506ea3c453e34940f88d",
                format = "json",
                noJsonCallback = 1,
                extras = "url_s",
                page = page,
                perPage = params.loadSize
            )

            val photos: List<GalleryItem> = response.photos.galleryItems

            LoadResult.Page(
                data = photos,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (photos.isEmpty()) null else page + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, GalleryItem>): Int? {
        return null
    }
}
