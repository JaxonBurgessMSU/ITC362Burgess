package com.bignerdranch.android.photogallery.api

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

private const val BASE_URL = "https://api.nasa.gov/"
private const val API_KEY = "2dSdi8P0Y7SHt6wg4mfFgEh5UDSfbvLfn1WYHVhq"

private val okHttpClient = OkHttpClient.Builder().build()

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

private val retrofit = Retrofit.Builder()
    .baseUrl(BASE_URL)
    .client(okHttpClient)
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .build()

interface NasaApi {
    @GET("planetary/apod")
    suspend fun fetchAstronomyPictureOfTheDay(
        @Query("api_key") apiKey: String = "2dSdi8P0Y7SHt6wg4mfFgEh5UDSfbvLfn1WYHVhq",
        @Query("format") format: String = "json",
        @Query("hd") hd: Boolean = true,
        @Query("count") count: Int = 20,
        @Query("start_date") startDate: String? = null,
        @Query("end_date") endDate: String? = null
    ): NasaResponse

    companion object {
        fun create(apiKey: String = API_KEY): NasaApi {
            return retrofit.newBuilder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(NasaApi::class.java)
                .apply {
                    (this as? retrofit2.Retrofit)?.let { retrofit ->
                        retrofit.newBuilder()
                            .addConverterFactory(MoshiConverterFactory.create(moshi))
                            .build()
                    }
                }
        }
    }
}

