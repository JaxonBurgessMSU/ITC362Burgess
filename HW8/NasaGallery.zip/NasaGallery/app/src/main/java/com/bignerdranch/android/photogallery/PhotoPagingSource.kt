package com.bignerdranch.android.photogallery

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.bignerdranch.android.photogallery.api.*

class PhotoPagingSource(
    private val nasaApi: NasaApi,
) : PagingSource<Int, GalleryItem>() {


    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, GalleryItem> {
        val page = params.key ?: 1

        return try {
            val response: NasaResponse = nasaApi.fetchAstronomyPictureOfTheDay(
                apiKey = "2dSdi8P0Y7SHt6wg4mfFgEh5UDSfbvLfn1WYHVhq",
                format = "json",
                hd = true,
                count = 20,
                startDate = null,
                endDate = null
            )

            val photos: List<GalleryItem> = response.photos.galleryItems

            LoadResult.Page(
                data = photos,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (photos.isEmpty()) null else page + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, GalleryItem>): Int? {
        return null
    }
}
