package com.bignerdranch.android.photogallery

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.bignerdranch.android.photogallery.api.NasaApi
import com.bignerdranch.android.photogallery.api.GalleryItem
import kotlinx.coroutines.flow.Flow

class PhotoRepository(private val nasaApi: NasaApi) {

    fun getPhotoPagingData(): Flow<PagingData<GalleryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = PAGE_SIZE,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { PhotoPagingSource(nasaApi) }
        ).flow
    }


    companion object {
        private const val PAGE_SIZE = 50

        fun create(apiKey: String): PhotoRepository {
            val nasaApi = NasaApi.create(apiKey)
            return PhotoRepository(nasaApi)
        }
    }
}
