import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import com.bignerdranch.android.photogallery.PhotoRepository
import com.bignerdranch.android.photogallery.api.GalleryItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

private const val TAG = "PhotoGalleryViewModel"

class PhotoGalleryViewModel : ViewModel() {

    private val _galleryItems: MutableStateFlow<PagingData<GalleryItem>> =
        MutableStateFlow(PagingData.empty())
    val galleryItems: StateFlow<PagingData<GalleryItem>>
        get() = _galleryItems.asStateFlow()

    init {
        fetchData()
    }

    private fun fetchData() {
        viewModelScope.launch {
            try {

                val photoRepository: PhotoRepository = PhotoRepository.create(apiKey = "2dSdi8P0Y7SHt6wg4mfFgEh5UDSfbvLfn1WYHVhq")


                photoRepository.getPhotoPagingData().collectLatest { pagingData ->
                    _galleryItems.value = pagingData
                }
            } catch (ex: Exception) {
                Log.e(TAG, "Failed to fetch gallery items", ex)
            }
        }
    }

}
