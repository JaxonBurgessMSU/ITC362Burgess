package com.bateman.msu.hw4courtcounter

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel

class ScoreViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {
    var scoreTeamA: Int = savedStateHandle.get("scoreTeamA") ?: 0
        set(value) {
            field = value
            savedStateHandle.set("scoreTeamA", value)
        }

    var scoreTeamB: Int = savedStateHandle.get("scoreTeamB") ?: 0
        set(value) {
            field = value
            savedStateHandle.set("scoreTeamB", value)
        }

    fun incrementScoreTeamA(points: Int) {
        scoreTeamA += points
    }

    fun incrementScoreTeamB(points: Int) {
        scoreTeamB += points
    }

    fun resetScores() {
        scoreTeamA = 0
        scoreTeamB = 0
    }
}











