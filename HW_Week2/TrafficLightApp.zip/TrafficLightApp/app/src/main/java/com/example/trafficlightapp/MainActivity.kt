package com.example.trafficlightapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {

    private lateinit var lightButton: Button
    private lateinit var redLight: ImageView
    private lateinit var yellowLight: ImageView
    private lateinit var greenLight: ImageView
    private var isStop: Boolean = false
    private var isGO: Boolean = false
    private var isWait: Boolean = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lightButton = findViewById(R.id.lightButton)
        redLight = findViewById(R.id.redLight)
        yellowLight = findViewById(R.id.yellowLight)
        greenLight = findViewById(R.id.greenLight)

        redLight.visibility = View.INVISIBLE
        greenLight.visibility = View.INVISIBLE
        yellowLight.visibility = View.INVISIBLE


        lightButton.setOnClickListener{
                if(isStop) {
                    lightButton.setBackgroundColor(ContextCompat.getColor(this, R.color.stop))
                    lightButton.text = "STOP"
                    redLight.visibility = View.VISIBLE
                    greenLight.visibility = View.INVISIBLE
                    yellowLight.visibility = View.INVISIBLE

                    isStop = false
                    isGO = true
                    isWait = false
                }
                else if(isGO){
                    lightButton.setBackgroundColor(ContextCompat.getColor(this, R.color.go))
                    lightButton.text = "GO"
                    redLight.visibility = View.INVISIBLE
                    greenLight.visibility = View.VISIBLE
                    yellowLight.visibility = View.INVISIBLE

                    isStop = false
                    isGO = false
                    isWait = true


                }
                else {
                    lightButton.setBackgroundColor(ContextCompat.getColor(this, R.color.wait))
                    lightButton.text = "WAIT"
                    redLight.visibility = View.INVISIBLE
                    greenLight.visibility = View.INVISIBLE
                    yellowLight.visibility = View.VISIBLE

                    isStop = true
                    isGO = false
                    isWait = false


                }
        }

    }

}