package com.bignerdranch.android.criminalintent

import androidx.lifecycle.ViewModel
import java.util.*

class CrimeListViewModel : ViewModel() {
    val crimes = mutableListOf<Crime>()

    init {
        for (i in 0 until 100) {
            val crime = Crime(
                id = UUID.randomUUID(),
                title = "Crime #$i",
                date = Date(),
                isSolved = i % 2 == 0
            )

            // You can set requiresPolice to true for specific crimes that need police intervention
            if (i % 5 == 0) {
                crime.requiresPolice = true
            }

            crimes.add(crime)
        }
    }
}
