package com.example.countapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var countButton: Button
    private lateinit var countDisplay: TextView
    private val count = Counter()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        countDisplay =  findViewById(R.id.count_display)  // (tv1 the id I gave my textview. Yours might be different)
        countButton =  findViewById(R.id.count_button)//(btn1 the id I gave my button. Yours might be different)


        countButton.setOnClickListener {
            count.addCount()

            countDisplay.text = count.getCount().toString()

        }
    }
}



class Counter {
    private var count: Int = 0
    fun addCount() {
        count++
    }

    fun getCount(): Int {
        return count
    }




}